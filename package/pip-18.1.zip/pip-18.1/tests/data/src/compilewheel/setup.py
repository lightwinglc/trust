#!/usr/bin/env python
from setuptools import find_packages, setup

setup(name='compilewheel',
      version='1.0',
      packages=find_packages()
      )
