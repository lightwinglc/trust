from setuptools import setup

setup(
    name="singlemodule",
    version='0.0.1',
    description="A sample Python project with a single module",
    py_modules=['singlemodule'],
)
