#!/usr/bin/env python
from setuptools import setup

setup(
    name='pep518_invalid_build_system',
    version='1.0.0',
    py_modules=['pep518'],
)
